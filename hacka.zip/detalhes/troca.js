
 function troca(){
    /*const api = axios.create({
        baseURL: 'https://backprovi54.herokuapp.com',
    })
    const listaProdutos = await api.get('/produtos');
    //console.log(listaProdutos);*/
    var resultados = document.getElementById("resultados");
    resultados.style.display = "block";

}

